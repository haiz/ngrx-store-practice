import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public people: any[] = [];
  public filter: String = 'ALL';

  addPerson(name) {
    this.people.push({name: name, guests: 0, attending: false});
  }

  updateFilter(filter) {
    console.log('oooo: ' + filter);
    this.filter = filter;
  }

  addGuest(person) {
    person.guests += 1;
  }

  removeGuest(person) {
    person.guests -= 1;
  }

  removePerson(person) {
    const index = this.people.indexOf(person);
    this.people.splice(index, 1);
  }

  toggleAttending(person) {
    person.attending = !person.attending;
  }
}
