import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'person-list',
  templateUrl: './person-list.component.html',
  styleUrls: ['./person-list.component.css']
})
export class PersonListComponent implements OnInit {
  @Input('people') people: any[];
  @Input('filter') filter: String;

  @Output() updateFilter = new EventEmitter();
  @Output() addGuest = new EventEmitter();
  @Output() removeGuest = new EventEmitter();
  @Output() toggleAttending = new EventEmitter();
  @Output() removePerson = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }

  show(person) {
    if (this.filter === 'ALL') {
      return true;
    } else if (this.filter === 'ATTENDING') {
      return person.attending;
    } else if (this.filter === 'GUEST') {
      return person.guests;
    }
    return false;
  }

  updateFilterL(person) {
    this.updateFilter.emit(person);
  }

  addGuestL(person) {
    this.addGuest.emit(person);
  }

  removeGuestL(person) {
    this.removeGuest.emit(person);
  }

  toggleAttendingL(person) {
    this.toggleAttending.emit(person);
  }

  removePersonL(person) {
    this.removePerson.emit(person);
  }
}
